
I'll help you add a custom LLM provider with those configuration parameters. This is a multi-step task that involves understanding the current provider system and adding support for a new custom provider type.

Let me start by exploring the codebase to understand how providers are currently implemented.


Let me continue exploring the API models and settings page to understand the full structure:


Now I have a good understanding of the system. Let me create a task plan for adding a custom LLM provider with the 6 required parameters.


Now let me start implementing the changes. I'll begin with the backend models and work through to the frontend.


Let me read the full config.py file to make the correct update:


I see the file got corrupted. Let me fix it:


The errors are pre-existing dependency issues, not related to my changes. Let me continue with updating the mutation functions and UI:


Now I need to update the Settings.tsx to add the custom provider fields. Let me update the ProviderDraft type and add UI fields for custom providers:


These are also pre-existing dependency errors. Let me continue with the UI changes for the Settings.tsx file. I need to add the custom fields UI in the ProvidersTab component:


Now I need to update the handleSave function to include the new fields:


Now let me add the Chinese translations as well:


Perfect! Now let me mark all tasks as complete and create a summary:


Perfect! I've successfully implemented the custom LLM provider with all 6 required configuration parameters. Here's a summary of what was done:

## Summary of Changes

### Backend (Python)

1. **[models.py](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/webui/api/models.py)** - Added 5 new fields to provider models:
   - `dsp_url`
   - `model_name`
   - `use_case_name`
   - `service_account`
   - `service_account_password` (with masking for security)

2. **[webui_config.py](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/webui/utils/webui_config.py)** - Updated documentation to reflect new custom provider fields

3. **[providers.py](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/webui/api/routes/providers.py)** - Updated API routes to:
   - Return new fields when listing providers
   - Accept new fields when creating providers
   - Update new fields when modifying providers
   - Properly mask `service_account_password` for security

4. **[provider.py](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/webui/patches/provider.py)** - Updated provider patch to properly handle custom dynamic providers

5. **[config.py](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/webui/patches/config.py)** - Fixed and maintained config patch for custom provider detection

### Frontend (React/TypeScript)

6. **[useProviders.ts](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/web/src/hooks/useProviders.ts)** - Updated TypeScript interfaces and mutation hooks to include new fields

7. **[Settings.tsx](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/web/src/pages/Settings.tsx)** - Added UI components:
   - New input fields for all 5 custom provider parameters
   - Conditional rendering (only shown for custom providers)
   - Proper draft state management for all new fields
   - Save handler updated to persist all new fields

8. **i18n translations** - Added translations for new fields in:
   - [en.json](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/web/src/i18n/locales/en.json) (English)
   - [zh.json](file:///d:/work/code-repo/github/nanobot-webui-0.2.6/web/src/i18n/locales/zh.json) (Chinese)

## How It Works

When users create a custom provider through the UI:
1. They enter a provider name and click "Add Custom Provider"
2. The provider appears in the list with an expandable section
3. When expanded, custom providers show additional fields:
   - DSP URL
   - Model Name
   - Use Case Name
   - Service Account
   - Service Account Password (masked input)
4. All fields are saved to `webui_config.json` under `custom_providers`
5. The service_account_password is properly masked when returned to the frontend

The implementation follows the existing patterns in the codebase and maintains backward compatibility with built-in providers.